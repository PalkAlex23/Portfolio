for i in range(100, 0, -1):
    if i % 10 == 1:
        print(i, end="\n")
    else:
        print(i, end=" ")
