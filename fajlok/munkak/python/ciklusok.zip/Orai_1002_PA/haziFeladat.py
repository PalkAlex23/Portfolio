osszeg = 0

# 9. feladat

# for i in range(1, 7):
#     print(i, end=", ")
# print(7)

# 14. feladat

# for i in range(10):
#     szam = float(input("Kérem adja meg a(z) "+str(i+1)+". negatív számot: "))
#     if szam < 0:
#         osszeg += szam
# print("A negatív számok összege: "+str(osszeg))

# 17. feladat

# for i in range(5):
#     szam = float(input("Kérem adja meg a(z) "+str(i+1)+". valós számot (5 db lesz bekérve): "))
#     osszeg += szam
# print("A valós számok összege: "+str(osszeg))

# 18. feladat

# mondat = []
#
# for i in range(5):
#     szo = input("Kérem adjon meg a(z)"+str(i+1)+". szót (5 szó lesz bekérve): ")
#     mondat.append(szo)
# for i in mondat:
#     print(i, end=" ")
