# from haziFeladat import *
# from csokken10Sor import *
# from parosSzam import *
from negyzetSzam import *
