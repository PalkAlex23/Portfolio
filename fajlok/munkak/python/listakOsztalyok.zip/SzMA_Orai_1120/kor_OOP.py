class Kor:
    def __init__(self, sugar, kozeppont):
        self.sugar = sugar
        self.kozeppont = kozeppont


kor01 = Kor(5, (3, 7))
print(kor01.sugar)

kor02 = Kor(10, (1, 1))
print(kor02.kozeppont)
