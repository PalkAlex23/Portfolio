def szoBeolvas():
    szo = input("Kérem adjon meg egy szót: ")
    return szo


def listaKiir(lista):
    index = 0
    while index < len(lista):
        print(lista[index]+" ", end="")
        index += 1


def alap():
    szavakListaja = []
    for db in range(1, 6, 1):
        szavakListaja.append(szoBeolvas())
    return szavakListaja


def otbetus(lista):
    db = 0
    for index in range(0, len(lista), 1):
        if len(lista[index]) == 5:
            db += 1
    print("\n\tAz 5 karakteres szavak száma: "+str(db))


def kBetu(lista):
    db = 0
    index = 0
    while index < len(lista):
        if "k" in lista[index]:
            db += 1
        index += 1
    print("\tA k betűt tartalmazó szavak száma: "+str(db)+".")
