kor_01 = {
    'kozepponnt': (2, 5),
    'sugar': 5
}


def terulet(kor):
    return kor['sugar'] * pow(3.14, 2)


def kerulet(kor):
    return kor['sugar'] * 2 * 3.14


print("A kör területe: "+str(terulet(kor_01))+" egység.")
