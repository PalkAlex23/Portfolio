def listaLegyart(honnet, meddig, lepeskoz, lista):
    for elem in range(honnet, meddig, lepeskoz):
        lista.append(elem)
    return lista


def alap():
    elso = []
    masodik = []

    # első lista
    # for elem in range(0, 30, 2):
    #     elso.append(elem)
    elso = listaLegyart(0, 30, 2, elso)

    # második lista
    # for elem in range(39, 21, -2):
    #     masodik.append(elem)
    masodik = listaLegyart(39, 21, -2, masodik)

    # egy listává összerakom
    eredmeny = []
    eredmeny.append(elso)
    eredmeny.append(masodik)
    return eredmeny


def osszefuz(eredmeny):
    elso = eredmeny[0]
    masodik = eredmeny[1]

    elso.extend(masodik)
    # print(elso)
    return elso


def kiir(lista):
    for index in range(0, len(lista), 1):
        print("{:>2d}".format(lista[index])+" ", end="")
        if index % 5 == 4:
            print("")
