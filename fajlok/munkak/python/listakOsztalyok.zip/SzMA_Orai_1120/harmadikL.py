from random import randint


def matek(meddig, oszthato):
    szamlista = []
    db = 0
    oszt = 0
    osszeg = 0
    for szam in range(1, meddig, 1):
        db += 1
        randomszam = randint(20, 30)
        if randomszam % oszthato == 0:
            oszt += 1
        szamlista.append(randomszam)
        osszeg += randomszam
    atlag = osszeg / db
    print(szamlista)
    print("\tA(z) "+str(oszthato)+" oszható számok száma: "+str(oszt))
    print("\tÁtlaga: "+str(round(atlag, 2)))
