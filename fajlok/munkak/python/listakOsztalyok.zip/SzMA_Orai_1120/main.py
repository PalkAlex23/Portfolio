# import elsoL
# import masodikL
# import oop_kor_szotar
import harmadikL


# szavakListaja = elsoL.alap()
# elsoL.listaKiir(szavakListaja)
# elsoL.otbetus(szavakListaja)
# elsoL.kBetu(szavakListaja)

# eredmeny = masodikL.alap()
# osszefuzott = masodikL.osszefuz(eredmeny)
# masodikL.kiir(osszefuzott)

# oop_kor_szotar.terulet()
harmadikL.matek(10, 2)
