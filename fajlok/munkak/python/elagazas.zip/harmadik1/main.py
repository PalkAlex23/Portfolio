# import pozitive
# from megelozoKovetkezoSzam import *
# import Osztalyzat1
import Osztalyzat2
