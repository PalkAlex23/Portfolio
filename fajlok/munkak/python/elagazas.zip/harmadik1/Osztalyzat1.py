szazalek = int(input("Adjon meg egy százalékértéket 0 és 100 között: "))

if (szazalek >= 0) and (szazalek <= 100):
    if (szazalek >= 0) and (szazalek <= 59):
        print("Az Ön osztályzata: elégtelen")
    elif (szazalek >= 60) and (szazalek <= 69):
        print("Az Ön osztályzata: elégséges")
    elif (szazalek >= 70) and (szazalek <= 79):
        print("Az Ön osztályzata: közepes")
    elif (szazalek >= 80) and (szazalek <= 89):
        print("Az Ön osztályzata: jó")
    else:
        print("Az Ön osztályzata: jeles")
else:
    print("Hiba: érvénytelen százalék!")
