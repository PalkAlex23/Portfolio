osztalyzat = int(input("Kérem adjon meg egy egész számot 1 és 5 között: "))

if (osztalyzat >= 1) and (osztalyzat <= 5):
    if osztalyzat == 1:
        print(str(osztalyzat)+" = elégtelen")
    elif osztalyzat == 2:
        print(str(osztalyzat) + " = elégséges")
    elif osztalyzat == 3:
        print(str(osztalyzat) + " = közepes")
    elif osztalyzat == 4:
        print(str(osztalyzat) + " = jó")
    else:
        print(str(osztalyzat) + " = jeles")
else:
    print("Érvénytelen osztályzat")
