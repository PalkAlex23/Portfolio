egeszSzam = int(input("Kérem adjon meg egy egész számot: "))

if (egeszSzam >= -9) and (egeszSzam <= 9):
    megelozo = egeszSzam - 1
    rakovetkezo = egeszSzam + 1
    print("A(z) "+str(egeszSzam)+" megelőző értéke: "+str(megelozo)+", és rákövetkező értéke: "+str(rakovetkezo))
