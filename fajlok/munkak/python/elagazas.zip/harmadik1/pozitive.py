pozitivSzam = int(input("Ez a program ellenőrzi, hogy az adott szám pozitív egész szám-e!\nKérem adjon meg a számot: "))
if pozitivSzam > 0:
    print("A szám pozitív.")
else:
    print("")
