Halál labirintus (Baksa Bence, Szabó-Mester Alex)
